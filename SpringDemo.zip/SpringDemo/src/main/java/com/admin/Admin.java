package com.admin;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.model.OneManyChild;
import com.model.OneManyMaster;
import com.model.OneToUserData;
import com.model.UserData;
import com.model.dao.GenericDao;


@Controller
public class Admin {

	@Autowired
	GenericDao s;

	@RequestMapping(value = "admin.demo", method = RequestMethod.GET)
	public String pageLoad(ModelMap m, HttpServletRequest req) {
		if (req.getParameter("id") != null) {
			int id = Integer.parseInt(req.getParameter("id"));
			m.put("mode", s.update(new UserData(), id));
		} else {
			m.put("mode", new UserData());
		}
		return "home";
	}

	@RequestMapping(value = "admin.demo", method = RequestMethod.POST)
	public String pageLoad1(@ModelAttribute("mode") UserData m, BindingResult rs) {
		s.insert(m);
		return "home";
	}

	@RequestMapping(value = "view.demo", method = RequestMethod.GET)
	public String pageLoad2(ModelMap m) {
		m.put("lisr", s.getData("UserData"));
		return "li";
	}

	@RequestMapping(value = "delete.demo", method = RequestMethod.GET)
	public String pageLoad3(@RequestParam("id") int id) {
		UserData ud = new UserData(id);
		s.delete(ud);
		return "redirect:view.demo";
	}

	@RequestMapping(value = "onetoone.demo", method = RequestMethod.GET)
	public String pageLoad4(ModelMap m, HttpServletRequest req) {
		if (req.getParameter("id") != null) {
			int id = Integer.parseInt(req.getParameter("id"));
			m.put("mode", s.update(new OneToUserData(), id));
		} else {
			m.put("lisr", s.getData("UserData"));
			m.put("mode", new OneToUserData());
		}
		return "rel";
	}

	@RequestMapping(value = "onetoone.demo", method = RequestMethod.POST)
	public String pageLoad5(@ModelAttribute("mode") OneToUserData m, BindingResult rs) {
		s.insert(m);
		return "rel";
	}

	@RequestMapping(value = "viewoneto.demo", method = RequestMethod.GET)
	public String pageLoad6(ModelMap m) {
		m.put("lisr", s.getData("OneToUserData"));
		return "liv";
	}

	@RequestMapping(value = "deleteoneto.demo", method = RequestMethod.GET)
	public String pageLoad7(@RequestParam("id") int id) {
		OneToUserData on = new OneToUserData(id);
		s.delete(on);
		return "redirect:viewoneto.demo";
	}

	@RequestMapping(value = "onetomany.demo", method = RequestMethod.GET)
	public String pageLoad8(ModelMap m) {
		//m.put("lisr", s.getData("OneManyMaster"));
		m.put("mode", new OneManyMaster());

		return "relm";
	}
	
	@RequestMapping(value = "onetomany.demo", method = RequestMethod.POST)
	public String pageLoad9(@ModelAttribute("mode") OneManyMaster m,BindingResult rs,@RequestParam("subject") String[] sb,@RequestParam("year") String[] ye) {
		
		m = s.insert(m);
		for (int i = 0; i < ye.length; i++) {
			OneManyChild ch = new OneManyChild(sb[i], ye[i], m);
			s.insert(ch);
		}
		return "lim";
	}
	
	@RequestMapping(value = "viewonetomany.demo", method = RequestMethod.GET)
	public String pageLoad10(ModelMap m) {
		m.put("lisr", s.getData("OneManyMaster"));
		return "lim";
	}
	
}
