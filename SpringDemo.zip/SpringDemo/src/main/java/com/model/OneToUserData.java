package com.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="user_data_one")
public class OneToUserData implements Serializable{
	
	@Id
	@GeneratedValue
	private int one_id;
	
	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="id")
	private UserData u;
	
	@Column(length=50)
	private String userName;
	
	@Column(length=50,unique=true)
	private long userNumber;

	public int getOne_id() {
		return one_id;
	}

	public void setOne_id(int one_id) {
		this.one_id = one_id;
	}	

	public UserData getU() {
		return u;
	}

	public void setU(UserData u) {
		this.u = u;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public long getUserNumber() {
		return userNumber;
	}

	public void setUserNumber(long userNumber) {
		this.userNumber = userNumber;
	}

	public OneToUserData(int one_id) {
		super();
		this.one_id = one_id;
	}

	public OneToUserData() {
		super();
	}
	
	
	
}
