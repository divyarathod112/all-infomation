package com.model.dao;

import java.util.List;

public interface GenericDao {
	
	<E> E insert(E e);
	
	List getData(String s);
	
	<E> void delete(E e);
	
	<E> E update(E e,int id);
}
