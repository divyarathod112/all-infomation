package com.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="user_data")
public class UserData implements Serializable{
	
	@Id
	@GeneratedValue
	private int id;
	
	@Column(length = 50)
	private String fname;
	
	@Column(length = 50)
	private String lname;
	
	@Column(length = 50,unique = true)
	private long number;
	
	@Column(length = 6)
	private String gender;
	
	@Column(length = 50)
	private String country;
	
	@Column(length = 200)
	private String address;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public long getNumber() {
		return number;
	}

	public void setNumber(long number) {
		this.number = number;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public UserData() {
		super();
	}

	public UserData(int id) {
		super();
		this.id = id;
	}

	
}
