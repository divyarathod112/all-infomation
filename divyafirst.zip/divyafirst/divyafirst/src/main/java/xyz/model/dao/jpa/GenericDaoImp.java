package xyz.model.dao.jpa;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import xyz.model.dao.GenericDao;

@Repository
public class GenericDaoImp implements GenericDao {
	@PersistenceContext
	private EntityManager en;

	@Transactional
	public <E> E insert(E e) {
		return en.merge(e);
	}

	@Transactional
	public <E> void delete(E e) {
		en.remove(en.merge(e));
	}

	@Transactional
	public int delete(String na,int id,String led) {
		Query q = en.createQuery("delete from " + na + " where "+led+" = '"+id+"'");
		return q.executeUpdate();
	}
	
	@Transactional
	public List getdata(String m) {
		Query q = en.createQuery("from " + m + "");
		return q.getResultList();
	}

	@Transactional
	public <E> E get(E e, int id) {

		E m = (E) en.find(e.getClass(), id);
		return m;
	}

}
