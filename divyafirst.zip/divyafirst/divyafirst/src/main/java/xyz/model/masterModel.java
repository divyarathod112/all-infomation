package xyz.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
@Entity
@Table(name="web_master")
public class masterModel implements Serializable {

	@Id
	@GeneratedValue
	private int master_id;
	
	@Column(length=40)
	private String fname;
	
	@Column(length=40)
	private long number;
	
	@OneToMany(mappedBy="m",fetch=FetchType.LAZY)
	private List<childModel> ch;
	
	

	public List<childModel> getCh() {
		return ch;
	}

	public void setCh(List<childModel> ch) {
		this.ch = ch;
	}

	public int getMaster_id() {
		return master_id;
	}

	public void setMaster_id(int master_id) {
		this.master_id = master_id;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public long getNumber() {
		return number;
	}

	public void setNumber(long number) {
		this.number = number;
	}
	
	
	
}
