package xyz.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
@Entity
@Table(name="web_child")
public class childModel implements Serializable {

	@Id
	@GeneratedValue
	private int child_id;
	
	@Column(length=40)
	private String subject;
	
	@Column(length=4)
	private String year;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="master_id")
	private masterModel m;

	public int getChild_id() {
		return child_id;
	}

	public String getSubject() {
		return subject;
	}

	public String getYear() {
		return year;
	}

	public masterModel getM() {
		return m;
	}

	public childModel(String subject, String year, masterModel m) {
		super();
		this.subject = subject;
		this.year = year;
		this.m = m;
	}

	public childModel() {
		super();
	}
	
	
	
	
	
}
