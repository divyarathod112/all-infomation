package xyz.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
@Entity
@Table(name="web_subject_table")
public class masModel implements Serializable {
	
	@Id
	@GeneratedValue
	private int subject_id;
	
	@Column(length=40)
	private String subject;
	
	@Column(length=4)
	private int year;
	
	@ManyToMany(cascade=CascadeType.ALL)
	@JoinTable(name = "web_subject_name", joinColumns = { @JoinColumn(name = "name_id") }
	, inverseJoinColumns = { @JoinColumn(name = "subject_id") })
	private List<chiModel> list = new ArrayList<chiModel>(0);

	public int getSubject_id() {
		return subject_id;
	}

	public String getSubject() {
		return subject;
	}

	public int getYear() {
		return year;
	}

	public List<chiModel> getList() {
		return list;
	}

	public masModel(String subject, int year, List<chiModel> list) {
		super();
		this.subject = subject;
		this.year = year;
		this.list = list;
	}

	public masModel() {
		super();
	}
	
	

	
	
}
