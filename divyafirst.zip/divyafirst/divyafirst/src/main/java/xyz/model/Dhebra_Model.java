package xyz.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table(name = "web_user_xyz")
public class Dhebra_Model implements Serializable {
	@Id
	@GeneratedValue
	private int xyz_id;
	
	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="id")
	private User_Model l;
	
	@Column(length = 50)
	private String xyz;
	
	@Column(length = 50,unique = true)
	private long pqr;

	public int getXyz_id() {
		return xyz_id;
	}

	public void setXyz_id(int xyz_id) {
		this.xyz_id = xyz_id;
	}

	public User_Model getL() {
		return l;
	}

	public void setL(User_Model l) {
		this.l = l;
	}

	public String getXyz() {
		return xyz;
	}

	public void setXyz(String xyz) {
		this.xyz = xyz;
	}

	public long getPqr() {
		return pqr;
	}

	public void setPqr(long pqr) {
		this.pqr = pqr;
	}
	
	
	

}
