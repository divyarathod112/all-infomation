package xyz.model.dao;

import java.util.List;

public interface GenericDao
{
	<E> E insert(E e);
	<E> void delete(E e);
	List getdata(String m);
	<E> E get(E e,int id);
	int delete(String na,int id,String led);
	
}
