package xyz.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="web_name_table")
public class chiModel  implements Serializable {
	
	@Id
	@GeneratedValue
	private int name_id;
	
	@Column(length=40)
	private String name;
	
	@Column(length=4)
	private long number;

	public chiModel(String name, long number) {
		super();
		this.name = name;
		this.number = number;
	}

	public chiModel() {
		super();
	}

	public int getName_id() {
		return name_id;
	}

	public String getName() {
		return name;
	}

	public long getNumber() {
		return number;
	}
}
