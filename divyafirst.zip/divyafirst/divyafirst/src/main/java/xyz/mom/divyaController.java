package xyz.mom;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import xyz.model.Dhebra_Model;
import xyz.model.User_Model;
import xyz.model.chiModel;
import xyz.model.childModel;
import xyz.model.masModel;
import xyz.model.masterModel;
import xyz.model.dao.GenericDao;



@Controller
public class divyaController {
	
	@Autowired
	GenericDao s;
	
	@Autowired
	ServletContext sx;
	
	
	public File getpa() {
		String path = sx.getRealPath("upload/");
		
		return new File(path);
	}

	@RequestMapping(value = "abc.divya",method = RequestMethod.GET)
	public String xyz() {
		
		return "mom";
	}
	
	@RequestMapping(value = "view.divya",method = RequestMethod.GET)
	public String xyz3(ModelMap m) {
		m.put("lisr",s.getdata("User_Model"));
		return "dhj";
	}
	@RequestMapping(value = "oneto.divya",method = RequestMethod.GET)
	public String xyz6(ModelMap m) {
		m.put("lisr",s.getdata("User_Model"));
		m.put("mode",new Dhebra_Model());
		return "so";
	}
	
	
	@RequestMapping(value = "ddd.divya",method = RequestMethod.GET)
	public String xyz1(ModelMap m,HttpServletRequest req) {
		
		if(req.getParameter("id") != null)
		{
			int id = Integer.parseInt(req.getParameter("id"));
			m.put("mode",s.get(new User_Model(),id));
		}
		else {
			m.put("mode",new User_Model());
		}
		return "tyu";
	}
	
	@RequestMapping(value = "delete.divya",method = RequestMethod.GET)
	public String xyz1(@RequestParam("id") int id) {
		
			/*s.delete("ch", id, "m.master_id");*/
		
			User_Model mk = new User_Model(id);
			s.delete(mk);
		
		return "redirect:view.divya";
	}
	
	
	
	@RequestMapping(value = "ddd.divya",method = RequestMethod.POST)
	public String xy(@ModelAttribute("mode") User_Model m,BindingResult rs,@RequestParam("img") MultipartFile mk) {
		
		if(mk != null)
		{
			try {
				mk.transferTo(new File(getpa(),mk.getOriginalFilename()));
				
				m.setImage(mk.getOriginalFilename());
				s.insert(m);
				
				
			}
			catch (IllegalStateException | IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return "tyu";
	}
	
	@RequestMapping(value = "oneto.divya",method = RequestMethod.POST)
	public String xysa(@ModelAttribute("mode") Dhebra_Model m,BindingResult rs) {
		
				s.insert(m);
		
		return "so";
	}
	
	@RequestMapping(value = "onetomany.divya",method = RequestMethod.GET)
	public String rt(ModelMap m) {
		m.put("lisr",s.getdata("masterModel"));
		m.put("mode",new masterModel());
		
		return "sof";
	}
	
	@RequestMapping(value = "manytomany.divya",method = RequestMethod.GET)
	public String rdt() {
		return "many";
	}

	@RequestMapping(value = "manytomany.divya",method = RequestMethod.POST)
	public String xysa(@RequestParam("subject") String[] sb,@RequestParam("year") 
	int[] ye,@RequestParam("name") String[] name,@RequestParam("number") long[] num) {
		
		List<chiModel> lo = new ArrayList<chiModel>();
		for (int i = 0; i < num.length; i++) {
		chiModel nj = new chiModel(name[i], num[i]);
		lo.add(nj);
		}
		
		for (int i = 0; i < ye.length; i++) {
			masModel ch = new masModel(sb[i], ye[i],lo);
			s.insert(ch);
		}
		return "many";
	}

	
	@RequestMapping(value = "onetomany.divya",method = RequestMethod.POST)
	public String xysai(@ModelAttribute("mode") masterModel m,BindingResult rs,@RequestParam("subject") String[] sb,@RequestParam("year") String[] ye) {
		
		m = s.insert(m);
		for (int i = 0; i < ye.length; i++) {
			childModel ch = new childModel(sb[i], ye[i], m);
			s.insert(ch);
		}
		return "sof";
	}
	
	

}
